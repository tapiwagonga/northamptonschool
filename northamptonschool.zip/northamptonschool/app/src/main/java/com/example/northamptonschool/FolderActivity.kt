package com.example.northamptonschool

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class FolderActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.actvity_folder)
        // Implementation for managing folders
    }
}
